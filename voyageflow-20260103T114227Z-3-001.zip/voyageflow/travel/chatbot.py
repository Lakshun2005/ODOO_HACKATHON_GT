import random
from .models import City, Activity, Trip

class VoyageBot:
    """Local keyword-based chatbot for travel assistance"""

    def __init__(self):
        self.responses = {
            'greeting': [
                'Welcome to VoyageFlow! I\'m VoyageBot, your travel assistant. How can I help you today?',
                'Hello! I\'m here to help you plan your perfect trip. What would you like to know?',
                'Hi there! Ready to explore the world? Ask me anything about travel planning!',
            ],
            'help': [
                'I can help you with: creating trips, finding cities, planning itineraries, tracking expenses, and more. What would you like to do?',
                'You can ask me about cities, activities, budget planning, or how to use the app features.',
            ],
            'cities': [
                f'We have {City.objects.count()} amazing cities available! Ask me about a specific country or use the discover feature to browse.',
                'VoyageFlow includes cities across the world. What region interests you?',
            ],
            'activities': [
                f'We have {Activity.objects.count()} exciting activities available across our cities!',
                'From adventure sports to cultural experiences, we have activities for everyone!',
            ],
            'budget': [
                'I can help you track spending! Use the budget analysis feature to see your spending patterns.',
                'Pro tip: Set a realistic budget and monitor daily expenses to avoid overspending.',
            ],
            'itinerary': [
                'Use the itinerary builder to: add cities, schedule activities, set dates, and organize your trip!',
                'Simply add cities to your trip, then schedule activities for each day. You can drag to reorder!',
            ],
            'expense': [
                'Track every penny! Log expenses in categories: accommodation, food, transport, activities, and shopping.',
                'Expenses are tracked automatically and show your budget health in real-time.',
            ],
            'sharing': [
                'You can share your itinerary publicly! Generate a shareable link and send it to friends.',
                'Public sharing lets others view your trip plan without editing capabilities.',
            ],
            'gratitude': [
                'You\'re welcome! Happy travels! 🌍',
                'Anytime! Let me know if you need anything else.',
            ],
            'default': [
                'That\'s a great question! I\'m still learning. Try asking about specific features or cities.',
                'I\'m not sure about that, but I\'m here to help with trip planning. What else can I assist with?',
                'Interesting! You can also explore the app features directly or check the help section.',
            ]
        }

    def get_response(self, user_input, user):
        """Generate bot response based on user input"""
        user_input_lower = user_input.lower()

        # Check for keywords and return appropriate response
        keywords = {
            'greeting': ['hi', 'hello', 'hey', 'greetings', 'welcome'],
            'help': ['help', 'how do i', 'how to', 'what can', 'guide', 'tutorial'],
            'cities': ['city', 'cities', 'destination', 'country', 'where', 'location'],
            'activities': ['activity', 'activities', 'things to do', 'attractions', 'experience'],
            'budget': ['budget', 'cost', 'money', 'spending', 'expensive', 'price', 'afford'],
            'itinerary': ['itinerary', 'plan', 'schedule', 'organize', 'trip planning'],
            'expense': ['expense', 'spending', 'spend', 'spent', 'track'],
            'sharing': ['share', 'public', 'send', 'friend', 'link'],
            'gratitude': ['thanks', 'thank you', 'appreciate', 'thankful'],
        }

        # Find matching category
        for category, words in keywords.items():
            if any(word in user_input_lower for word in words):
                return random.choice(self.responses[category])

        # Add personalization based on user's trips
        if 'trip' in user_input_lower:
            trip_count = user.trips.count()
            if trip_count > 0:
                return f'You have {trip_count} trip(s) planned! I can help you create more or organize existing ones.'

        # Default response
        return random.choice(self.responses['default'])

    @staticmethod
    def get_city_suggestions(country=None):
        """Get city suggestions based on country"""
        if country:
            cities = City.objects.filter(country__icontains=country)
        else:
            cities = City.objects.all()

        return [f"{city.name}, {city.country}" for city in cities[:5]]

    @staticmethod
    def get_activity_suggestions(city_id):
        """Get activity suggestions for a city"""
        activities = Activity.objects.filter(city_id=city_id)
        return [activity.name for activity in activities[:5]]
