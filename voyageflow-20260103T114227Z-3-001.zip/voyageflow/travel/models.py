from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
from django.db.models import Sum
import uuid

class UserProfile(models.Model):
    """Extended user profile with saved destinations"""
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    bio = models.TextField(blank=True)
    profile_picture = models.ImageField(upload_to='profiles/', blank=True, null=True)
    favorite_destinations = models.ManyToManyField('City', blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.user.username}'s Profile"

class City(models.Model):
    """Pre-populated cities for the travel ecosystem"""
    name = models.CharField(max_length=100)
    country = models.CharField(max_length=100)
    description = models.TextField()
    latitude = models.FloatField()
    longitude = models.FloatField()
    best_season = models.CharField(max_length=100)
    average_daily_cost = models.DecimalField(max_digits=10, decimal_places=2)
    image_url = models.CharField(max_length=255, default='')
    attractions = models.TextField(help_text="Comma-separated attractions")

    class Meta:
        unique_together = ('name', 'country')

    def __str__(self):
        return f"{self.name}, {self.country}"

class Trip(models.Model):
    """Main trip entity"""
    STATUS_CHOICES = [
        ('planning', 'Planning'),
        ('ongoing', 'Ongoing'),
        ('completed', 'Completed'),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='trips')
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    start_date = models.DateField()
    end_date = models.DateField()
    budget = models.DecimalField(max_digits=12, decimal_places=2)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='planning')
    is_public = models.BooleanField(default=False)
    public_token = models.CharField(max_length=50, unique=True, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def get_total_expenses(self):
        """Calculate total expenses for the trip"""
        return self.expenses.aggregate(total=Sum('amount'))['total'] or 0

    def get_remaining_budget(self):
        """Calculate remaining budget"""
        return self.budget - self.get_total_expenses()

    def get_theoretical_spending(self):
        """Calculate theoretical spending: (B_total / D_total) * D_completed"""
        from datetime import datetime

        total_days = (self.end_date - self.start_date).days + 1
        days_passed = (min(datetime.now().date(), self.end_date) - self.start_date).days + 1

        if total_days == 0:
            return 0

        theoretical = (float(self.budget) / total_days) * days_passed
        return theoretical

    def is_overspending(self):
        """Check if user is overspending relative to trip progress"""
        spent = float(self.get_total_expenses())
        theoretical = self.get_theoretical_spending()
        return spent > theoretical

    def __str__(self):
        return self.title

class Stop(models.Model):
    """A city stop in a trip itinerary"""
    trip = models.ForeignKey(Trip, on_delete=models.CASCADE, related_name='stops')
    city = models.ForeignKey(City, on_delete=models.CASCADE)
    order = models.PositiveIntegerField()
    check_in_date = models.DateField()
    check_out_date = models.DateField()
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ['order']
        unique_together = ('trip', 'order')

    def __str__(self):
        return f"{self.trip.title} - {self.city.name}"

class Activity(models.Model):
    """Activities available in cities"""
    city = models.ForeignKey(City, on_delete=models.CASCADE, related_name='activities')
    name = models.CharField(max_length=150)
    description = models.TextField()
    category = models.CharField(max_length=50, choices=[
        ('sightseeing', 'Sightseeing'),
        ('adventure', 'Adventure'),
        ('cultural', 'Cultural'),
        ('food', 'Food & Dining'),
        ('shopping', 'Shopping'),
        ('nightlife', 'Nightlife'),
        ('relaxation', 'Relaxation'),
        ('other', 'Other'),
    ])
    estimated_cost = models.DecimalField(max_digits=10, decimal_places=2)
    duration_hours = models.FloatField()
    rating = models.FloatField(default=4.5, help_text="Rating out of 5")
    image_url = models.CharField(max_length=255, default='')

    def __str__(self):
        return f"{self.name} in {self.city.name}"

class ItineraryActivity(models.Model):
    """Activities planned for a specific day in a stop"""
    stop = models.ForeignKey(Stop, on_delete=models.CASCADE, related_name='planned_activities')
    activity = models.ForeignKey(Activity, on_delete=models.SET_NULL, null=True, blank=True)
    custom_activity = models.CharField(max_length=200, blank=True, null=True)
    scheduled_time = models.TimeField()
    notes = models.TextField(blank=True)
    order = models.PositiveIntegerField()

    class Meta:
        ordering = ['order']

    def __str__(self):
        return f"{self.stop} - {self.activity or self.custom_activity}"

class Expense(models.Model):
    """Track expenses during a trip"""
    trip = models.ForeignKey(Trip, on_delete=models.CASCADE, related_name='expenses')
    category = models.CharField(max_length=50, choices=[
        ('accommodation', 'Accommodation'),
        ('food', 'Food & Dining'),
        ('transport', 'Transport'),
        ('activities', 'Activities'),
        ('shopping', 'Shopping'),
        ('other', 'Other'),
    ])
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    description = models.CharField(max_length=200)
    date = models.DateField(default=timezone.now)
    currency = models.CharField(max_length=3, default='USD')

    class Meta:
        ordering = ['-date']

    def __str__(self):
        return f"{self.trip.title} - {self.category}: {self.amount}"

class ChatMessage(models.Model):
    """VoyageBot chat messages"""
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='chat_messages')
    message = models.TextField()
    response = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-timestamp']

    def __str__(self):
        return f"{self.user.username} - {self.timestamp}"

class SharedItinerary(models.Model):
    """Public sharing of itineraries"""
    trip = models.OneToOneField(Trip, on_delete=models.CASCADE, related_name='shared_itinerary')
    shared_token = models.CharField(max_length=50, unique=True)
    shared_at = models.DateTimeField(auto_now_add=True)
    view_count = models.IntegerField(default=0)

    def __str__(self):
        return f"Shared: {self.trip.title}"
