from django.urls import path
from . import views

urlpatterns = [
    # Authentication
    path('signup/', views.signup, name='signup'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),

    # Dashboard & Main
    path('', views.dashboard, name='dashboard'),
    path('dashboard/', views.dashboard, name='dashboard'),

    # Trip Management
    path('trips/create/', views.create_trip, name='create_trip'),
    path('trips/<uuid:trip_id>/', views.trip_detail, name='trip_detail'),
    path('trips/<uuid:trip_id>/edit/', views.edit_trip, name='edit_trip'),
    path('trips/<uuid:trip_id>/delete/', views.delete_trip, name='delete_trip'),

    # Itinerary & Stops
    path('trips/<uuid:trip_id>/add-stop/', views.add_stop, name='add_stop'),
    path('trips/<uuid:trip_id>/reorder-stops/', views.reorder_stops, name='reorder_stops'),
    path('stops/<int:stop_id>/add-activity/', views.add_activity, name='add_activity'),

    # Cities & Discovery
    path('cities/', views.discover_cities, name='discover_cities'),
    path('cities/<int:city_id>/', views.city_detail, name='city_detail'),

    # Expenses
    path('trips/<uuid:trip_id>/add-expense/', views.add_expense, name='add_expense'),
    path('trips/<uuid:trip_id>/budget-analysis/', views.budget_analysis, name='budget_analysis'),

    # Chatbot
    path('chatbot/', views.chatbot_view, name='chatbot'),
    path('chatbot/send/', views.send_chat_message, name='send_chat_message'),

    # Public Sharing
    path('trips/<uuid:trip_id>/share/', views.share_itinerary_public, name='share_itinerary'),
    path('public/<str:token>/', views.view_public_itinerary, name='public_itinerary'),

    # Profile
    path('profile/', views.profile, name='profile'),

    # API Endpoints
    path('api/trips/<uuid:trip_id>/data/', views.api_get_trip_data, name='api_trip_data'),
    path('api/cities/search/', views.api_search_cities, name='api_search_cities'),
]
