from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.http import JsonResponse, HttpResponse
from django.views.decorators.http import require_POST
from django.utils.text import slugify
from django.db.models import Sum, Q
from django.utils import timezone
import json
import uuid
import secrets
from datetime import datetime, timedelta

from .models import (
    UserProfile, City, Trip, Stop, Activity, ItineraryActivity, 
    Expense, ChatMessage, SharedItinerary
)
from .chatbot import VoyageBot
from .utils import generate_public_token

# ==================== AUTHENTICATION ====================

def signup(request):
    """User registration"""
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        password_confirm = request.POST.get('password_confirm')

        if password != password_confirm:
            return render(request, 'travel/signup.html', {'error': 'Passwords do not match'})

        if User.objects.filter(username=username).exists():
            return render(request, 'travel/signup.html', {'error': 'Username already exists'})

        user = User.objects.create_user(username=username, email=email, password=password)
        UserProfile.objects.create(user=user)

        return redirect('login')

    return render(request, 'travel/signup.html')

def login_view(request):
    """User login"""
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            return redirect('dashboard')
        else:
            return render(request, 'travel/login.html', {'error': 'Invalid credentials'})

    return render(request, 'travel/login.html')

def logout_view(request):
    """User logout"""
    logout(request)
    return redirect('login')

# ==================== DASHBOARD ====================

@login_required
def dashboard(request):
    """Main dashboard - overview of trips and budget"""
    user = request.user
    trips = user.trips.all()

    total_budget = sum(float(trip.budget) for trip in trips)
    total_spent = sum(float(trip.get_total_expenses()) for trip in trips)
    remaining = total_budget - total_spent

    context = {
        'trips': trips,
        'total_budget': total_budget,
        'total_spent': total_spent,
        'remaining': remaining,
        'upcoming_trips': trips.filter(start_date__gte=timezone.now().date(), status='planning'),
    }
    return render(request, 'travel/dashboard.html', context)

# ==================== TRIP MANAGEMENT ====================

@login_required
def create_trip(request):
    """Create a new trip"""
    if request.method == 'POST':
        title = request.POST.get('title')
        description = request.POST.get('description')
        start_date = request.POST.get('start_date')
        end_date = request.POST.get('end_date')
        budget = request.POST.get('budget')

        trip = Trip.objects.create(
            user=request.user,
            title=title,
            description=description,
            start_date=start_date,
            end_date=end_date,
            budget=budget,
        )

        return redirect('trip_detail', trip_id=trip.id)

    return render(request, 'travel/create_trip.html')

@login_required
def trip_detail(request, trip_id):
    """View trip details and manage itinerary"""
    trip = get_object_or_404(Trip, id=trip_id, user=request.user)
    stops = trip.stops.all()
    expenses = trip.expenses.all()
    theoretical_spending = trip.get_theoretical_spending()
    actual_spending = trip.get_total_expenses()
    is_overspending = trip.is_overspending()

    context = {
        'trip': trip,
        'stops': stops,
        'expenses': expenses,
        'theoretical_spending': theoretical_spending,
        'actual_spending': actual_spending,
        'is_overspending': is_overspending,
        'remaining_budget': trip.get_remaining_budget(),
    }
    return render(request, 'travel/trip_detail.html', context)

@login_required
def edit_trip(request, trip_id):
    """Edit trip details"""
    trip = get_object_or_404(Trip, id=trip_id, user=request.user)

    if request.method == 'POST':
        trip.title = request.POST.get('title', trip.title)
        trip.description = request.POST.get('description', trip.description)
        trip.start_date = request.POST.get('start_date', trip.start_date)
        trip.end_date = request.POST.get('end_date', trip.end_date)
        trip.budget = request.POST.get('budget', trip.budget)
        trip.save()

        return redirect('trip_detail', trip_id=trip.id)

    return render(request, 'travel/edit_trip.html', {'trip': trip})

@login_required
def delete_trip(request, trip_id):
    """Delete a trip"""
    trip = get_object_or_404(Trip, id=trip_id, user=request.user)
    trip.delete()
    return redirect('dashboard')

# ==================== CITY & ACTIVITY DISCOVERY ====================

@login_required
def discover_cities(request):
    """Search and browse available cities"""
    query = request.GET.get('q', '')
    country = request.GET.get('country', '')

    cities = City.objects.all()

    if query:
        cities = cities.filter(Q(name__icontains=query) | Q(description__icontains=query))

    if country:
        cities = cities.filter(country=country)

    countries = City.objects.values_list('country', flat=True).distinct()

    context = {
        'cities': cities,
        'countries': sorted(set(countries)),
        'query': query,
    }
    return render(request, 'travel/discover_cities.html', context)

@login_required
def city_detail(request, city_id):
    """View city details and activities"""
    city = get_object_or_404(City, id=city_id)
    activities = city.activities.all()

    context = {
        'city': city,
        'activities': activities,
    }
    return render(request, 'travel/city_detail.html', context)

# ==================== ITINERARY BUILDER ====================

@login_required
def add_stop(request, trip_id):
    """Add a city stop to trip"""
    trip = get_object_or_404(Trip, id=trip_id, user=request.user)

    if request.method == 'POST':
        city_id = request.POST.get('city_id')
        check_in = request.POST.get('check_in_date')
        check_out = request.POST.get('check_out_date')

        city = get_object_or_404(City, id=city_id)

        max_order = trip.stops.aggregate(max_order=Sum('order'))['max_order'] or 0

        stop = Stop.objects.create(
            trip=trip,
            city=city,
            order=max_order + 1,
            check_in_date=check_in,
            check_out_date=check_out,
        )

        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse({'success': True, 'stop_id': stop.id})

        return redirect('trip_detail', trip_id=trip.id)

    cities = City.objects.all()
    return render(request, 'travel/add_stop.html', {'trip': trip, 'cities': cities})

@login_required
def reorder_stops(request, trip_id):
    """Reorder stops (drag and drop)"""
    trip = get_object_or_404(Trip, id=trip_id, user=request.user)

    if request.method == 'POST':
        data = json.loads(request.body)
        stop_ids = data.get('stop_ids', [])

        for index, stop_id in enumerate(stop_ids, 1):
            Stop.objects.filter(id=stop_id, trip=trip).update(order=index)

        return JsonResponse({'success': True})

    return JsonResponse({'error': 'Invalid request'}, status=400)

@login_required
def add_activity(request, stop_id):
    """Add activity to an itinerary stop"""
    stop = get_object_or_404(Stop, id=stop_id, trip__user=request.user)

    if request.method == 'POST':
        activity_id = request.POST.get('activity_id')
        custom_activity = request.POST.get('custom_activity')
        scheduled_time = request.POST.get('scheduled_time')

        max_order = stop.planned_activities.aggregate(max=Sum('order'))['max'] or 0

        if activity_id:
            activity = get_object_or_404(Activity, id=activity_id)
            ItineraryActivity.objects.create(
                stop=stop,
                activity=activity,
                scheduled_time=scheduled_time,
                order=max_order + 1,
            )
        else:
            ItineraryActivity.objects.create(
                stop=stop,
                custom_activity=custom_activity,
                scheduled_time=scheduled_time,
                order=max_order + 1,
            )

        return redirect('trip_detail', trip_id=stop.trip.id)

    activities = Activity.objects.filter(city=stop.city)
    return render(request, 'travel/add_activity.html', {'stop': stop, 'activities': activities})

# ==================== EXPENSE TRACKING ====================

@login_required
def add_expense(request, trip_id):
    """Add an expense to a trip"""
    trip = get_object_or_404(Trip, id=trip_id, user=request.user)

    if request.method == 'POST':
        category = request.POST.get('category')
        amount = request.POST.get('amount')
        description = request.POST.get('description')
        date = request.POST.get('date', timezone.now().date())

        Expense.objects.create(
            trip=trip,
            category=category,
            amount=amount,
            description=description,
            date=date,
        )

        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse({'success': True, 'remaining': float(trip.get_remaining_budget())})

        return redirect('trip_detail', trip_id=trip.id)

    return render(request, 'travel/add_expense.html', {'trip': trip})

# ==================== BUDGET ANALYSIS ====================

@login_required
def budget_analysis(request, trip_id):
    """Detailed budget analysis and visualization"""
    trip = get_object_or_404(Trip, id=trip_id, user=request.user)

    # Calculate spending by category
    expense_by_category = trip.expenses.values('category').annotate(
        total=Sum('amount')
    ).order_by('-total')

    # Daily spending analysis
    expenses_by_date = trip.expenses.values('date').annotate(
        total=Sum('amount')
    ).order_by('date')

    context = {
        'trip': trip,
        'expense_by_category': list(expense_by_category),
        'expenses_by_date': list(expenses_by_date),
        'theoretical_spending': trip.get_theoretical_spending(),
        'actual_spending': trip.get_total_expenses(),
        'is_overspending': trip.is_overspending(),
    }
    return render(request, 'travel/budget_analysis.html', context)

# ==================== CHATBOT ====================

@login_required
def chatbot_view(request):
    """VoyageBot chat interface"""
    user = request.user
    chat_history = user.chat_messages.all()[:50]

    context = {
        'chat_history': reversed(chat_history),
    }
    return render(request, 'travel/chatbot.html', context)

@login_required
def send_chat_message(request):
    """Handle chatbot messages via AJAX"""
    if request.method == 'POST':
        user_message = request.POST.get('message', '').strip()

        if not user_message:
            return JsonResponse({'error': 'Empty message'}, status=400)

        bot = VoyageBot()
        bot_response = bot.get_response(user_message, request.user)

        ChatMessage.objects.create(
            user=request.user,
            message=user_message,
            response=bot_response,
        )

        return JsonResponse({
            'user_message': user_message,
            'bot_response': bot_response,
        })

    return JsonResponse({'error': 'Invalid request'}, status=400)

# ==================== PUBLIC SHARING ====================

def share_itinerary_public(request, trip_id):
    """Generate public share link"""
    trip = get_object_or_404(Trip, id=trip_id, user=request.user)

    if not trip.public_token:
        trip.public_token = secrets.token_urlsafe(32)
        trip.is_public = True
        trip.save()

    share_url = request.build_absolute_uri(f'/travel/public/{trip.public_token}/')

    return render(request, 'travel/share_itinerary.html', {
        'trip': trip,
        'share_url': share_url,
    })

def view_public_itinerary(request, token):
    """View shared itinerary publicly"""
    trip = get_object_or_404(Trip, public_token=token, is_public=True)

    # Increment view count
    shared, _ = SharedItinerary.objects.get_or_create(trip=trip)
    shared.view_count += 1
    shared.save()

    stops = trip.stops.all()
    expenses = trip.expenses.all()

    context = {
        'trip': trip,
        'stops': stops,
        'expenses': expenses,
        'is_public': True,
    }
    return render(request, 'travel/public_itinerary.html', context)

# ==================== USER PROFILE ====================

@login_required
def profile(request):
    """User profile management"""
    profile = get_object_or_404(UserProfile, user=request.user)

    if request.method == 'POST':
        profile.bio = request.POST.get('bio', profile.bio)
        if request.FILES.get('profile_picture'):
            profile.profile_picture = request.FILES['profile_picture']
        profile.save()

        return redirect('profile')

    context = {
        'profile': profile,
        'favorites': profile.favorite_destinations.all(),
    }
    return render(request, 'travel/profile.html', context)

# ==================== API ENDPOINTS ====================

@login_required
def api_get_trip_data(request, trip_id):
    """API endpoint for getting trip data (for charts)"""
    trip = get_object_or_404(Trip, id=trip_id, user=request.user)

    expense_by_category = trip.expenses.values('category').annotate(
        total=Sum('amount')
    )

    data = {
        'trip_id': str(trip.id),
        'title': trip.title,
        'budget': float(trip.budget),
        'spent': float(trip.get_total_expenses()),
        'remaining': float(trip.get_remaining_budget()),
        'theoretical_spending': trip.get_theoretical_spending(),
        'is_overspending': trip.is_overspending(),
        'expense_categories': list(expense_by_category),
    }

    return JsonResponse(data)

@login_required
def api_search_cities(request):
    """API endpoint for city search"""
    query = request.GET.get('q', '')

    cities = City.objects.filter(
        Q(name__icontains=query) | 
        Q(country__icontains=query)
    )[:10]

    data = {
        'cities': [
            {'id': city.id, 'name': city.name, 'country': city.country}
            for city in cities
        ]
    }

    return JsonResponse(data)
