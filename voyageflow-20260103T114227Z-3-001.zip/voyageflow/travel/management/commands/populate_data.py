from django.core.management.base import BaseCommand
from travel.models import City, Activity
from decimal import Decimal

class Command(BaseCommand):
    help = 'Populate database with initial cities and activities'

    def handle(self, *args, **options):
        # Sample cities data
        cities_data = [
            {
                'name': 'Paris',
                'country': 'France',
                'description': 'The City of Light - iconic landmarks, world-class museums, and romantic charm.',
                'latitude': 48.8566,
                'longitude': 2.3522,
                'best_season': 'April-June, September-October',
                'average_daily_cost': Decimal('150.00'),
                'attractions': 'Eiffel Tower, Louvre Museum, Notre-Dame, Versailles Palace',
                'image_url': 'https://via.placeholder.com/300x200?text=Paris'
            },
            {
                'name': 'Tokyo',
                'country': 'Japan',
                'description': 'A vibrant metropolis blending ancient tradition with cutting-edge technology.',
                'latitude': 35.6762,
                'longitude': 139.6503,
                'best_season': 'March-May, September-November',
                'average_daily_cost': Decimal('120.00'),
                'attractions': 'Senso-ji Temple, Meiji Shrine, Shinjuku, Tokyo Skytree',
                'image_url': 'https://via.placeholder.com/300x200?text=Tokyo'
            },
            {
                'name': 'New York City',
                'country': 'USA',
                'description': 'The city that never sleeps - iconic skyscrapers, diverse neighborhoods, world-class entertainment.',
                'latitude': 40.7128,
                'longitude': -74.0060,
                'best_season': 'April-May, September-October',
                'average_daily_cost': Decimal('200.00'),
                'attractions': 'Statue of Liberty, Central Park, Times Square, Metropolitan Museum',
                'image_url': 'https://via.placeholder.com/300x200?text=NYC'
            },
            {
                'name': 'Barcelona',
                'country': 'Spain',
                'description': 'A coastal city known for its architecture, beaches, and vibrant cultural scene.',
                'latitude': 41.3874,
                'longitude': 2.1686,
                'best_season': 'April-May, September-October',
                'average_daily_cost': Decimal('100.00'),
                'attractions': 'Sagrada Familia, Park Güell, Gothic Quarter, Montjuïc',
                'image_url': 'https://via.placeholder.com/300x200?text=Barcelona'
            },
            {
                'name': 'Sydney',
                'country': 'Australia',
                'description': 'A harbor city famous for its Opera House, beaches, and outdoor lifestyle.',
                'latitude': -33.8688,
                'longitude': 151.2093,
                'best_season': 'September-November, March-May',
                'average_daily_cost': Decimal('130.00'),
                'attractions': 'Opera House, Bondi Beach, Harbour Bridge, Royal Botanic Garden',
                'image_url': 'https://via.placeholder.com/300x200?text=Sydney'
            },
            {
                'name': 'Rome',
                'country': 'Italy',
                'description': 'The Eternal City - home to ancient ruins, Renaissance art, and delicious cuisine.',
                'latitude': 41.9028,
                'longitude': 12.4964,
                'best_season': 'April-May, September-October',
                'average_daily_cost': Decimal('100.00'),
                'attractions': 'Colosseum, Vatican City, Roman Forum, Trevi Fountain',
                'image_url': 'https://via.placeholder.com/300x200?text=Rome'
            },
            {
                'name': 'London',
                'country': 'United Kingdom',
                'description': 'Historic capital blending royal heritage with modern culture and innovation.',
                'latitude': 51.5074,
                'longitude': -0.1278,
                'best_season': 'May-June, September',
                'average_daily_cost': Decimal('140.00'),
                'attractions': 'Big Ben, Tower of London, Buckingham Palace, British Museum',
                'image_url': 'https://via.placeholder.com/300x200?text=London'
            },
            {
                'name': 'Bangkok',
                'country': 'Thailand',
                'description': 'A bustling city known for temples, street food, and vibrant nightlife.',
                'latitude': 13.7563,
                'longitude': 100.5018,
                'best_season': 'November-February',
                'average_daily_cost': Decimal('40.00'),
                'attractions': 'Grand Palace, Wat Pho, Floating Markets, Lumphini Park',
                'image_url': 'https://via.placeholder.com/300x200?text=Bangkok'
            },
            {
                'name': 'Dubai',
                'country': 'UAE',
                'description': 'A modern oasis in the desert with luxury shopping, iconic skyscrapers, and beaches.',
                'latitude': 25.2048,
                'longitude': 55.2708,
                'best_season': 'October-April',
                'average_daily_cost': Decimal('150.00'),
                'attractions': 'Burj Khalifa, Palm Jumeirah, Gold Souk, Desert Safari',
                'image_url': 'https://via.placeholder.com/300x200?text=Dubai'
            },
            {
                'name': 'Amsterdam',
                'country': 'Netherlands',
                'description': 'A charming city famous for its canals, bicycles, museums, and progressive culture.',
                'latitude': 52.3676,
                'longitude': 4.9041,
                'best_season': 'April-May, September',
                'average_daily_cost': Decimal('110.00'),
                'attractions': 'Anne Frank House, Van Gogh Museum, Canal Cruises, Windmills',
                'image_url': 'https://via.placeholder.com/300x200?text=Amsterdam'
            },
        ]

        # Create cities
        cities_dict = {}
        for city_data in cities_data:
            city, created = City.objects.get_or_create(
                name=city_data['name'],
                country=city_data['country'],
                defaults=city_data
            )
            cities_dict[city.name] = city
            if created:
                self.stdout.write(self.style.SUCCESS(f'Created city: {city.name}'))

        # Activities data
        activities_data = {
            'Paris': [
                {'name': 'Visit Eiffel Tower', 'category': 'sightseeing', 'estimated_cost': Decimal('25.00'), 'duration_hours': 3, 'rating': 4.8},
                {'name': 'Louvre Museum Tour', 'category': 'cultural', 'estimated_cost': Decimal('20.00'), 'duration_hours': 4, 'rating': 4.7},
                {'name': 'Seine River Cruise', 'category': 'sightseeing', 'estimated_cost': Decimal('15.00'), 'duration_hours': 2, 'rating': 4.6},
                {'name': 'French Cooking Class', 'category': 'food', 'estimated_cost': Decimal('100.00'), 'duration_hours': 3, 'rating': 4.9},
                {'name': 'Shopping at Champs-Élysées', 'category': 'shopping', 'estimated_cost': Decimal('50.00'), 'duration_hours': 3, 'rating': 4.4},
            ],
            'Tokyo': [
                {'name': 'Senso-ji Temple Visit', 'category': 'cultural', 'estimated_cost': Decimal('5.00'), 'duration_hours': 2, 'rating': 4.7},
                {'name': 'Sushi Making Class', 'category': 'food', 'estimated_cost': Decimal('80.00'), 'duration_hours': 2.5, 'rating': 4.8},
                {'name': 'Shibuya Crossing Experience', 'category': 'sightseeing', 'estimated_cost': Decimal('0.00'), 'duration_hours': 1, 'rating': 4.6},
                {'name': 'Mt. Fuji Day Trip', 'category': 'adventure', 'estimated_cost': Decimal('150.00'), 'duration_hours': 12, 'rating': 4.9},
                {'name': 'Robot Restaurant Show', 'category': 'nightlife', 'estimated_cost': Decimal('80.00'), 'duration_hours': 2, 'rating': 4.5},
            ],
            'New York City': [
                {'name': 'Statue of Liberty Tour', 'category': 'sightseeing', 'estimated_cost': Decimal('30.00'), 'duration_hours': 4, 'rating': 4.8},
                {'name': 'Broadway Show', 'category': 'nightlife', 'estimated_cost': Decimal('120.00'), 'duration_hours': 3, 'rating': 4.7},
                {'name': 'Central Park Bike Tour', 'category': 'adventure', 'estimated_cost': Decimal('50.00'), 'duration_hours': 3, 'rating': 4.6},
                {'name': 'Metropolitan Museum', 'category': 'cultural', 'estimated_cost': Decimal('28.00'), 'duration_hours': 4, 'rating': 4.7},
                {'name': 'NYC Food Tour', 'category': 'food', 'estimated_cost': Decimal('75.00'), 'duration_hours': 3, 'rating': 4.8},
            ],
            'Barcelona': [
                {'name': 'Sagrada Familia Tour', 'category': 'cultural', 'estimated_cost': Decimal('33.00'), 'duration_hours': 3, 'rating': 4.8},
                {'name': 'Park Güell Visit', 'category': 'sightseeing', 'estimated_cost': Decimal('16.00'), 'duration_hours': 2.5, 'rating': 4.7},
                {'name': 'Beach Day', 'category': 'relaxation', 'estimated_cost': Decimal('0.00'), 'duration_hours': 5, 'rating': 4.6},
                {'name': 'Tapas Food Tour', 'category': 'food', 'estimated_cost': Decimal('50.00'), 'duration_hours': 3, 'rating': 4.9},
                {'name': 'Gothic Quarter Exploration', 'category': 'sightseeing', 'estimated_cost': Decimal('0.00'), 'duration_hours': 2, 'rating': 4.5},
            ],
            'Sydney': [
                {'name': 'Opera House Tour', 'category': 'cultural', 'estimated_cost': Decimal('43.00'), 'duration_hours': 2, 'rating': 4.8},
                {'name': 'Bondi Beach Swim', 'category': 'relaxation', 'estimated_cost': Decimal('0.00'), 'duration_hours': 3, 'rating': 4.7},
                {'name': 'Harbour Bridge Climb', 'category': 'adventure', 'estimated_cost': Decimal('340.00'), 'duration_hours': 4, 'rating': 4.9},
                {'name': 'Blue Mountains Day Trip', 'category': 'adventure', 'estimated_cost': Decimal('120.00'), 'duration_hours': 10, 'rating': 4.6},
                {'name': 'Australian Food Experience', 'category': 'food', 'estimated_cost': Decimal('60.00'), 'duration_hours': 3, 'rating': 4.7},
            ],
            'Rome': [
                {'name': 'Colosseum Visit', 'category': 'sightseeing', 'estimated_cost': Decimal('18.50'), 'duration_hours': 2, 'rating': 4.8},
                {'name': 'Vatican City Tour', 'category': 'cultural', 'estimated_cost': Decimal('30.00'), 'duration_hours': 4, 'rating': 4.9},
                {'name': 'Trevi Fountain Night Visit', 'category': 'sightseeing', 'estimated_cost': Decimal('0.00'), 'duration_hours': 1, 'rating': 4.7},
                {'name': 'Italian Cooking Class', 'category': 'food', 'estimated_cost': Decimal('90.00'), 'duration_hours': 3, 'rating': 4.8},
                {'name': 'Roman Forum Exploration', 'category': 'cultural', 'estimated_cost': Decimal('12.00'), 'duration_hours': 2.5, 'rating': 4.6},
            ],
            'London': [
                {'name': 'Big Ben & Parliament Tour', 'category': 'cultural', 'estimated_cost': Decimal('35.00'), 'duration_hours': 2, 'rating': 4.7},
                {'name': 'British Museum', 'category': 'cultural', 'estimated_cost': Decimal('0.00'), 'duration_hours': 4, 'rating': 4.8},
                {'name': 'Thames River Cruise', 'category': 'sightseeing', 'estimated_cost': Decimal('18.00'), 'duration_hours': 2, 'rating': 4.6},
                {'name': 'Afternoon Tea Experience', 'category': 'food', 'estimated_cost': Decimal('50.00'), 'duration_hours': 2, 'rating': 4.8},
                {'name': 'West End Theatre Show', 'category': 'nightlife', 'estimated_cost': Decimal('80.00'), 'duration_hours': 3, 'rating': 4.7},
            ],
            'Bangkok': [
                {'name': 'Grand Palace Tour', 'category': 'cultural', 'estimated_cost': Decimal('10.00'), 'duration_hours': 3, 'rating': 4.8},
                {'name': 'Floating Market Visit', 'category': 'shopping', 'estimated_cost': Decimal('5.00'), 'duration_hours': 3, 'rating': 4.7},
                {'name': 'Thai Cooking Class', 'category': 'food', 'estimated_cost': Decimal('25.00'), 'duration_hours': 3, 'rating': 4.9},
                {'name': 'Muay Thai Boxing Show', 'category': 'nightlife', 'estimated_cost': Decimal('30.00'), 'duration_hours': 2, 'rating': 4.6},
                {'name': 'Street Food Tour', 'category': 'food', 'estimated_cost': Decimal('10.00'), 'duration_hours': 2.5, 'rating': 4.8},
            ],
            'Dubai': [
                {'name': 'Burj Khalifa Top', 'category': 'sightseeing', 'estimated_cost': Decimal('120.00'), 'duration_hours': 2, 'rating': 4.8},
                {'name': 'Desert Safari', 'category': 'adventure', 'estimated_cost': Decimal('80.00'), 'duration_hours': 5, 'rating': 4.7},
                {'name': 'Gold Souk Shopping', 'category': 'shopping', 'estimated_cost': Decimal('100.00'), 'duration_hours': 3, 'rating': 4.5},
                {'name': 'Dune Bashing & Camel Ride', 'category': 'adventure', 'estimated_cost': Decimal('60.00'), 'duration_hours': 4, 'rating': 4.6},
                {'name': 'Luxury Dining Experience', 'category': 'food', 'estimated_cost': Decimal('200.00'), 'duration_hours': 3, 'rating': 4.9},
            ],
            'Amsterdam': [
                {'name': 'Canal Cruise', 'category': 'sightseeing', 'estimated_cost': Decimal('15.00'), 'duration_hours': 2, 'rating': 4.7},
                {'name': 'Anne Frank House', 'category': 'cultural', 'estimated_cost': Decimal('15.00'), 'duration_hours': 2, 'rating': 4.8},
                {'name': 'Van Gogh Museum', 'category': 'cultural', 'estimated_cost': Decimal('20.00'), 'duration_hours': 3, 'rating': 4.8},
                {'name': 'Windmill Tour', 'category': 'sightseeing', 'estimated_cost': Decimal('25.00'), 'duration_hours': 3, 'rating': 4.6},
                {'name': 'Pancake Tasting', 'category': 'food', 'estimated_cost': Decimal('20.00'), 'duration_hours': 1.5, 'rating': 4.7},
            ],
        }

        # Create activities
        for city_name, activities in activities_data.items():
            city = cities_dict.get(city_name)
            if city:
                for activity_data in activities:
                    activity, created = Activity.objects.get_or_create(
                        city=city,
                        name=activity_data['name'],
                        defaults=activity_data
                    )
                    if created:
                        self.stdout.write(self.style.SUCCESS(f'Created activity: {activity.name}'))

        self.stdout.write(self.style.SUCCESS('Database populated successfully!'))
