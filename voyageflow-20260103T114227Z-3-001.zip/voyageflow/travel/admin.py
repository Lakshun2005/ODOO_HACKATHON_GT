from django.contrib import admin
from .models import (
    UserProfile, City, Trip, Stop, Activity, ItineraryActivity,
    Expense, ChatMessage, SharedItinerary
)

@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'created_at')
    search_fields = ('user__username',)

@admin.register(City)
class CityAdmin(admin.ModelAdmin):
    list_display = ('name', 'country', 'average_daily_cost', 'best_season')
    search_fields = ('name', 'country')
    list_filter = ('country', 'best_season')

@admin.register(Trip)
class TripAdmin(admin.ModelAdmin):
    list_display = ('title', 'user', 'start_date', 'end_date', 'status', 'budget')
    search_fields = ('title', 'user__username')
    list_filter = ('status', 'start_date')

@admin.register(Stop)
class StopAdmin(admin.ModelAdmin):
    list_display = ('trip', 'city', 'order', 'check_in_date')
    search_fields = ('trip__title', 'city__name')
    list_filter = ('trip',)

@admin.register(Activity)
class ActivityAdmin(admin.ModelAdmin):
    list_display = ('name', 'city', 'category', 'estimated_cost', 'rating')
    search_fields = ('name', 'city__name')
    list_filter = ('category', 'city')

@admin.register(ItineraryActivity)
class ItineraryActivityAdmin(admin.ModelAdmin):
    list_display = ('stop', 'activity', 'scheduled_time')
    search_fields = ('stop__trip__title', 'activity__name')

@admin.register(Expense)
class ExpenseAdmin(admin.ModelAdmin):
    list_display = ('trip', 'category', 'amount', 'date', 'currency')
    search_fields = ('trip__title', 'description')
    list_filter = ('category', 'date')

@admin.register(ChatMessage)
class ChatMessageAdmin(admin.ModelAdmin):
    list_display = ('user', 'timestamp')
    search_fields = ('user__username',)
    list_filter = ('timestamp',)

@admin.register(SharedItinerary)
class SharedItineraryAdmin(admin.ModelAdmin):
    list_display = ('trip', 'shared_at', 'view_count')
    search_fields = ('trip__title',)
