import secrets
from datetime import datetime, timedelta
from django.utils import timezone

def generate_public_token(length=32):
    """Generate a secure random token for public sharing"""
    return secrets.token_urlsafe(length)

def calculate_trip_duration(start_date, end_date):
    """Calculate trip duration in days"""
    return (end_date - start_date).days + 1

def format_currency(amount, currency='USD'):
    """Format amount as currency"""
    return f"{currency} {float(amount):,.2f}"

def get_trip_progress_percentage(trip):
    """Get trip progress as percentage"""
    total_days = (trip.end_date - trip.start_date).days + 1
    days_passed = (min(datetime.now().date(), trip.end_date) - trip.start_date).days + 1

    if total_days <= 0:
        return 0

    return min(100, (days_passed / total_days) * 100)

def get_budget_health_color(percentage):
    """Get color based on budget health percentage"""
    if percentage > 100:
        return 'danger'  # Red - overspending
    elif percentage > 80:
        return 'warning'  # Yellow - caution
    else:
        return 'success'  # Green - good
